# Firestore Collections

- leads
- campaigns
- clickStats
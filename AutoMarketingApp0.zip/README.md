# Auto Marketing App

Install with Expo, connect Firebase, and deploy functions.